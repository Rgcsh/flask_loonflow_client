# -*- coding: utf-8 -*-
# (C) Wu Dong, 2019
# All rights reserved
__author__ = 'Wu Dong <wudong@eastwu.cn>'
__time__ = '2019-04-19 10:53'
VERSION = (2, 0, 0)

__version__ = '.'.join(map(str, VERSION))
