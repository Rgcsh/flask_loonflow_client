# -*- coding: utf-8 -*-
# (C) Wu Dong, 2019
# All rights reserved
__author__ = 'Wu Dong <wudong@eastwu.cn>'
__time__ = '2019-04-19 10:52'
# sys
import os
from datetime import timedelta

# 3p
from loguru import logger

# project
from .macro import k_log_path, k_log_name, k_log_enqueue, k_log_format
from .macro import k_log_rotation, k_log_serialize, k_log_retention


class Logger(object):
    """This class is used to config loguru
    """

    def __init__(self, app=None, config=None):
        if not (config is None or isinstance(config, dict)):
            raise ValueError("`config` must be an instance of dict or None")

        self.config = config

        if app is not None:
            self.init_app(app, config)

    def init_app(self, app, config=None):
        """This is used to initialize logger with your app object
        """
        if not (config is None or isinstance(config, dict)):
            raise ValueError("`config` must be an instance of dict or None")

        base_config = app.config.copy()
        if self.config:
            base_config.update(self.config)
        if config:
            base_config.update(config)

        config = base_config

        config.setdefault(k_log_path, None)
        config.setdefault(k_log_name, "")
        # 默认翻转时间为1小时
        config.setdefault(k_log_rotation, 60 * 60)
        # 默认压缩时间为7天
        config.setdefault(k_log_retention, 86400 * 7)
        config.setdefault(k_log_format, "")
        config.setdefault(k_log_enqueue, True)
        config.setdefault(k_log_serialize, True)

        self._set_loguru(app, config)

    def _set_loguru(self, app, config):
        """ Config logru
        """
        path = config[k_log_name]
        if config[k_log_path] is not None:
            path = os.path.join(config[k_log_path], config[k_log_name])

        logger.add(path, format=config[k_log_format], rotation=timedelta(seconds=config[k_log_rotation]),
                   enqueue=config[k_log_enqueue], serialize=config[k_log_serialize],
                   retention=timedelta(seconds=config[k_log_retention]))

        if not hasattr(app, "extensions"):
            app.extensions = {}

        app.extensions.setdefault("loguru", {})
        app.extensions["loguru"][self] = logger
